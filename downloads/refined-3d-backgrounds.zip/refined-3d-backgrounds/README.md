# Refined Three.js backgrounds

包含已下载的体积火焰模块、原始噪声/火焰纹理、Three官方水面法线纹理，以及主页使用的两种场景和共用React渲染器。

This is a source and texture bundle for React/Vite/Three, not a standalone HTML export. Copy src/ and public/ into the existing homepage project. The existing Three.js version is0.187.0. No extra renderer framework is required.

Usage:

    import RefinedSceneBackground from './components/RefinedSceneBackground'
    <RefinedSceneBackground kind="fire" paused={false} />

Use kind="water" for fine reflective water. In the actual homepage, pass the reduced-motion preference and the motion-control state to paused.

## Sources and licenses

- Fire: Housz/ThreeVolumetricFire, fixed commit ed1ee936cd451384a744bb6cd5c85454764b5ecc. MIT Copyright2025Housz. Original module/textures unchanged; the local factory adds instance grading, shape and embers. https://github.com/Housz/ThreeVolumetricFire
- Water: official Three0.187Water with original waternormals.jpg. MIT Copyright2010-2026three.js authors. https://threejs.org/examples/webgl_shaders_ocean.html
- Original license text and adaptation notes are retained in third-party/. Resource URLs and hashes are in third-party/refined-background-downloads.json.
- The effects are decorative volumetric/optical materials, not measured flow/combustion simulation results.
